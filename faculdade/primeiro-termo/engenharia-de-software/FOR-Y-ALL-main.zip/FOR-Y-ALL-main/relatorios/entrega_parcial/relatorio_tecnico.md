# Relatório Técnico - Entrega Parcial

**Data:** 11/04/2025
**Versão:** 1.0
**Equipe:**

- [Gustavo de Oliveira] - [Project Owner]
- [Guilherme Teixeira] - [Scrum Master]
- [Daniel dos Santos] - [DEV]
- [André luis] - [DEV]
- [Lucas Vitor] - [DEV]
- [Caue Moreno] - [DEV]
  
## 1. Resumo Executivo

[Finalizamos o projeto de Alta Fidelidade no Figma, ou seja, o processo da Prototipagem e Design de Interface está 100% finalizado]

## 2. Introdução

### 2.1 Objetivo do Projeto

[O objetivo principal do projeto é desenvolver um software com design de interface intuitivo e prático com a finalidade de gerar traduções e tirar dúvidas sobre alguma gramatica específica de um idioma específico]

### 2.2 Escopo

[Nosso projeto visa a criação de um app/site que ajudará pessoas que não possuem nenhuma intimidade com outras línguas. A interface basicamente servirá como um guia de tradução para a pessoa utilizar (seja em casos de viagens, trabalho, etc.), garantindo uma maneira de entendimento mais dinâmica, pois não será necessariamente um app voltado ao ensino. Basicamente, o projeto irá realizar traduções para o usuário, indicando o tipo de tradução que será utilizada e qual o contexto dessa tradução.]

### 2.3 Metodologia

[Utilizamos a metodologia do Framework SCRUM, fazendo definição de que seria responsável por cada papel (DEVs, Scrum Master, Product Owner) para que tivéssemos uma base no gerenciamento de atividades e tarefas que iriamos realizar. Utilizamos mais sua estrutura de definição de papéis do que as estruturas de tarefas(como a Daily Scrum, Sprint Review,etc...); realizamos entrevistas para conseguir estar criando um ambiente mais real do que seria a conversa com nossos Stakeholders, proporcionando uma discussão de ideias e interesses sobre o que eles tem como meta e o que futuros usuários esperam, unindo à Análise de Documentação que fizemos e desenvolvemos para verificar quais itens deveriam ser adicionados e quais não eram viáveis de se manter na estrutura; Histórias de Usuário foi a ferramenta mais utilizada por nossa parte, já que criava situações sobre o que nosso app devia estar atuando além de indicar ferramentas e características que seriam necessárias aos nossos diferentes públicos, junto com a dinâmica de apresentar elas em sala de aula, conseguimos auxílios e sugestões do que realizar de melhorias, tanto por outros grupos quanto pelo nosso mestre.]

## 3. Análise de Requisitos

### 3.1 Requisitos Funcionais

[| RF01 | Interface intuitiva: A interface do usuário (UI) deve ser simples e fácil de navegar para todos os níveis de usuário.| [Alta/Média/Baixa] |Add commentMore actions

| RF02 | Precisão na tradução: O aplicativo deve fornecer traduções precisas e contextualmente relevantes, com mínimo de erros. | [Alta/Média/Baixa] |

| RF03 | Tradução de texto e voz: Deve permitir tanto a tradução de texto escrito quanto a tradução por meio de entrada de voz. | ... |

| RF04 | Reconhecimento de voz: O aplicativo deve ser capaz de reconhecer diferentes sotaques e pronúncias nas traduções por voz. | ... |

| RF05 | Armazenamento de histórico de traduções: O usuário deve poder acessar e revisar traduções anteriores. | ... |

| RF06 | Modo offline: Deve permitir a tradução sem necessidade de conexão com a internet, utilizando um banco de dados local. | ... |

| RF07 | Suporte a traduções de documentos: O aplicativo deve ser capaz de traduzir textos em diferentes formatos de documentos (PDF, DOCX, etc.). | ... |

| RF08 | Sincronização em múltiplos dispositivos: O usuário deve poder sincronizar seu histórico de traduções e preferências entre dispositivos diferentes. | ... |

| RF09 | Tradução contextual: O aplicativo deve entender o contexto das palavras e frases para oferecer traduções mais precisas (por exemplo, palavras com múltiplos significados). | ... |

| RF10 |Correção de gramática e estilo: O aplicativo pode sugerir melhorias no texto traduzido, oferecendo correções gramaticais e sugestões de estilo. | ... |

| RF11 | Suporte a tradução de imagens: A funcionalidade de OCR (Reconhecimento Óptico de Caracteres) deve permitir a tradução de texto dentro de imagens ou fotos. | ... |

| RF12 | Feedback do usuário: Os usuários devem poder fornecer feedback sobre a qualidade das traduções, ajudando a melhorar o sistema. | ... |

| RF13 | Segurança de dados: O aplicativo deve garantir que as traduções e dados do usuário sejam tratados de forma segura, com criptografia adequada. | ... |

| RF14 | Acessibilidade: O aplicativo deve ser acessível para usuários com necessidades especiais, como compatibilidade com leitores de tela ou tradução em linguagem de sinais. | ... |

| RF15 | Suporte a múltiplos idiomas: O aplicativo deve ser capaz de traduzir entre diversos idiomas, incluindo idiomas populares e menos comuns. | ... |]

### 3.2 Requisitos Não Funcionais

[Felizmente, não identificamos nenhum requisito não funcional]

### 3.3 Matriz de Rastreabilidade

[Será elaborada em breve na próxima fase, conforme a implementação do código avançar.]

## 4. Arquitetura e Design

### 4.1 Visão Geral da Arquitetura

[O Modelo selecionado foi a de Arquitetura Cliente-Servidor.   Add commentMore actions
MOTIVO: Como nosso projeto tem a função de ser um aplicativo de realizar traduções, o modelo foi o que melhor se encaixou na estrutura do projeto, já que basicamente o usuário entraria no app e realizaria sua requisição, que seria a tradução, independente do método de mensagem(texto, áudio, imagem) e o app(servidor) daria a resposta da requisição, que no caso seria a tradução pronta e com opções de visibilidade para o usuário acessar.]

### 4.2 Diagramas

```mermaid

classDiagram
direction TB
    class Usuario {
	    +idade : int
	    +nivelDeConhecimento : int
    }

    class Localizacao {
	    +linguaNativa : str
	    +linguaDestinada : str
	    +traducao() : void
    }

    class Preferencias {
	    +formalidade : str
	    +sotaque : str
	    +contexto : str
    }

    class Comunicacao {
	    +OCR Translate() : void
    }

    class Tela {
	    +comandosSimples : str
	    +pontosFocais() : void
    }

    class Tecla {
	    +botoesIntuitivos() : void
    }

    class Conexao {
	    +pacotesDeIdiomas() : void
    }

    class Arquivos {
        +traduzesOffline() : void
    }
    Usuario --> Tela
    Tela --> Tecla
    Tecla --> Comunicacao
    Tecla --> Localizacao
    Tecla --> Conexao
    Tecla --> Arquivos
    Localizacao --> Preferencias

```
### 4.3 Decisões de Design

[Optamos pela escolha de fontes simples com cores claras para facilitar a visualização do usuário; as cores mais predominantes foram azul e amarelo em uma tonalidade que causa certo grau de conforto em sua utilização]

### 4.4 Protótipos

[Desenvolvemos, pelo Figma, um Protótipo de Média Fidelidade e outro de Alta Fidelidade. Ambos foram concluídos e já foram enviados no Moodle ("Prototipagem e Design de Interface: Desenvolvimento de Protótipos de Média Fidelidade")]

## 5. Implementação Atual

### 5.1 Funcionalidades Implementadas

[Interface intuitiva: A interface do usuário (UI) deve ser simples e fácil de navegar para todos os níveis de usuário.Add commentMore actions
Acessibilidade: O aplicativo deve ser acessível para usuários com necessidades especiais, como compatibilidade com leitores de tela ou tradução em linguagem de sinais.
Suporte a múltiplos idiomas: O aplicativo deve ser capaz de traduzir entre diversos idiomas, incluindo idiomas populares e menos comuns.]

### 5.2 Tecnologias Utilizadas

[Tudo foi feito pelo Figma, no momento. Estão todos inseridos no Protótipo de Alta Fidelidade]

### 5.3 Código-fonte

[Ainda em DESENVOLVIMENTO, por conta do foco ter sido na prototipagem pelo Figma]

## 6. Testes

### 6.1 Abordagem de Teste

[Realizamos testes manuais de usabilidade focando na navegação da interface, clareza dos elementos e coerência entre componentes. Também utilizamos casos de teste com base nas funcionalidades previstas para garantir que os fluxos do usuário fossem respeitados.]

### 6.2 Testes Realizados

- [Teste de coerência visual entre textos e imagens.]

- [Teste de tradução automática em tempo real.]

- [Testes de clareza dos botões e acessibilidade.]

### 6.3 Resultados

[Todos os testes manuais realizados foram satisfatórios, com destaque para:]
- [Boa legibilidade dos textos;]
- [Traduções dentro do tempo esperado (≤1s);]
- [Interface responsiva e coerente;]
- [Pontos de melhoria identificados foram registrados para ajuste futuro.]

## 7. Progresso do Projeto

### 7.1 Cronograma

[A maior parte do cronograma está em dia. A fase de prototipagem foi concluída antes do prazo. O início do desenvolvimento foi adiado para permitir ajustes finos no design.]

### 7.2 Sprints Concluídas

- [Sprint 1: Levantamento de requisitos e análise de documentação;]

- [Sprint 2: Criação de histórias de usuário e fluxogramas;]

- [Sprint 3: Prototipagem de Média Fidelidade;]

- [Sprint 4: Finalização do Protótipo de Alta Fidelidade.]

### 7.3 Métricas

- [100% dos requisitos funcionais priorizados para esta fase foram prototipados;]
- [90% de aprovação em testes de usabilidade em sala;]
- [Nenhum bug crítico identificado até o momento.]

## 8. Desafios e Soluções

### 8.1 Principais Desafios

- [Dificuldade em conciliar ideias divergentes da equipe no início do projeto.]
- [Entendimento inicial limitado sobre boas práticas em prototipagem.]
- [Ajustes constantes no layout por conta de feedbacks.]

### 8.2 Soluções Adotadas

- [Realização de reuniões semanais com pauta pré-definida.]
- [Estudos em conjunto sobre UI/UX no Figma.]
- [Validação contínua dos protótipos com colegas e professor.]

## 9. Próximos Passos

### 9.1 Funcionalidades Planejadas

[Iniciarmos o processo de desenvolvimento do Código-Fonte, assim, iniciarmos um teste prático do sistema e anotar possíveis mudanças.]

### 9.2 Melhorias Previstas

[Evitar certos bugs, um código limpo e polido.]

### 9.3 Cronograma Atualizado

[Cronograma atualizado para a conclusão do projeto]

## 10. Lições Aprendidas

[Entendemos melhor o funcionamento do Figma (exploramos ferramentas e desenvolvemos protótipos com boa dinânima); conseguimos entender melhor sobre Diagramas e também sobre Arquitetura de Design]

## 11. Conclusão

[Conseguimos finalizar tudo relacionado ao Protótipo e iniciaremos o projeto em si futuramente.]

## 12. Anexos

[Nenhum anexo ou documento complementar.]

>[!NOTE]
>Este relatório representa o estado do projeto na data da entrega parcial. Alterações e evoluções ocorrerão na segunda fase do desenvolvimento.
