# Projeto Integrador - Engenharia de Software

## Sobre o Projeto

Nome: [FOR Y'ALL]

[O objetivo principal do projeto é desenvolver um software com design de interface intuitivo e prático com a finalidade de gerar traduções e tirar dúvidas sobre alguma gramatica específica de um idioma específico]

## Equipe

- [Gustavo de Oliveira] - [Project Owner/PO]
- [Guilherme Alves] - [Scrum Master]
- [Daniel dos Santos] - [DEV]
- [André luis] - [DEV]
- [Lucas Vitor] - [DEV]
- [Caue Moreno] - [DEV]

## Tecnologias Utilizadas

- [Figma (criação de protótipos de média e alta fidelidade)]
- [Google Docs (organização e gerenciamento de tarefas)]
- [Ibis Paint (desenvolvimento de logotipo e protótipo de baixa fidelidade)]
- [Mermaid Chart para criação de Diagrama de Classes]

## Estrutura do Repositório

- `/diario/semanas`
- `/docs/requisitos/historias_usuario`
- `/docs/arquitetura/diagramas/casos_de_teste`
- `/docs/arquitetura/diagramas/casos_de_uso`
- `/docs/arquitetura/documento_arquitetura.md`
- `/docs/processo/Padrões_de_codificação.md`
- `/docs/processo/template_padroes_de_codificacao.md`
- `/relatorios/entrega_parcial/relatorio_tecnico.md`
- `/relatorios/entrega_parcial/relatório_final.md`
- `/DIARIO (15-04-2025).md`

## Como Executar o Projeto

[No momento, ele está apenas disponivel no Figma (https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?node-id=0-1&t=mcCu4LfnNpydBhzE-1). Precisa apenas clicar em iniciar no canto superior direito do projeto no Fgima e verá como ele funcionará, ainda não iniciamos o processo de codificação e desenvolvimento do código-fonte!]

## Status do Projeto

[Protótipos de Média e Alta Fidelidade concluídos, desenvolvimento do código-fonte ainda em processo inicial.]

## Entregas

- Entrega Parcial: 11/04/2025
- Entrega Final: 06/06/2025
