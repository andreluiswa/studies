# Ata de Reunião - Sprint XX

**Data:** DD/MM/AAAA
**Horário:** HH:MM - HH:MM
**Local:** [Local/Plataforma]
**Participantes:**

- [Nome do Participante 1]
- [Nome do Participante 2]
- [Nome do Participante n]

## 1. Pauta

- [Item 1 da pauta]
- [Item 2 da pauta]
- [Item n da pauta]

## 2. Discussões

### 2.1 [Item 1 da pauta]

[Resumo das discussões sobre o item 1]

### 2.2 [Item 2 da pauta]

[Resumo das discussões sobre o item 2]

### 2.n [Item n da pauta]

[Resumo das discussões sobre o item n]

## 3. Decisões

- [Decisão 1]
- [Decisão 2]
- [Decisão n]

## 4. Sprint Planning

### 4.1 Sprint Goal

[Objetivo da Sprint]

### 4.2 Sprint Backlog

| ID   | Descrição   | Responsável   | Estimativa (Story Points) | Prioridade   |
| ---- | ----------- | ------------- | ------------------------- | ------------ |
| [ID] | [Descrição] | [Responsável] | [Estimativa]              | [Prioridade] |
| [ID] | [Descrição] | [Responsável] | [Estimativa]              | [Prioridade] |
| ...  | ...         | ...           | ...                       | ...          |

## 5. Impedimentos

| Impedimento     | Responsável por Resolver | Prazo   |
| --------------- | ------------------------ | ------- |
| [Impedimento 1] | [Responsável]            | [Prazo] |
| [Impedimento 2] | [Responsável]            | [Prazo] |
| ...             | ...                      | ...     |

## 6. Próximos Passos

- [Próximo passo 1]
- [Próximo passo 2]
- [Próximo passo n]

## 7. Ações Pendentes

| Ação     | Responsável   | Prazo   |
| -------- | ------------- | ------- |
| [Ação 1] | [Responsável] | [Prazo] |
| [Ação 2] | [Responsável] | [Prazo] |
| ...      | ...           | ...     |

>[!IMPORTANT]
>Esta ata deve ser revisada e aprovada por todos os participantes até DD/MM/AAAA.
