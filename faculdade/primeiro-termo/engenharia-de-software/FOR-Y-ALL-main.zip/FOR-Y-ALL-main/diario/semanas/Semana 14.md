## Semana 14

### Informações Básicas

**Data:** 27/05/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Elaboração de Guia de Estilo Básico]

### Atividades Realizadas

**Descrição das atividades:**

- [- Principais Cores (Logo, Background e alguns Ícones): #00467A & #FFBF21]
- [Cores Secundárias (alguns Ícones, Botões, Textos e outros Background): #000000; #DEF1FF; #30A7FF; #18649E; #339BEA; #00233D]
- [Tipografia (Fontes, Tamanhos, Espaçamentos): - Fontes: Inter; - Tamanhos: de 12 à 24; - Espaçamentos: de 10 à 18] 
- [Componentes Padrão: - Botões de Login e Cadastro (Senha também); - Botões de Ação Rápida; - Botões para Menu; - Botão para Seção de Idiomas; - Botões para Edição de Perfil; - Aplicação de Elementos abordados no documento “Aplicação de Princípios de DesignCentrado no Usuário”]
- [Ícones e Elementos Gráficos utilizados: - Ícone de Câmera; - Ícone de Áudio; - Ícone de Mensagens Temporárias; - Ícone de Anexar Imagem; - Ícone de Anexar Documento; - Ícone de Menu; - Ícone das Opções do Menu; - Ícone de Botão para Voltar; - Ícone de Botão para Seção de Idiomas - Ícone de Edição de Perfil]
- [Linguagem para Mensagens ao Usuário: - Linguagem da norma padrão da língua, com um linguajar direto e simples para facilitação e compreensão de funções do app (Ex:“Digite aqui”,”Digite a Senha”,”Digite o E-mail)]
**Artefatos produzidos:**

- [Wireframe no FIGMA] - [Link de acesso: https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?t=xDPc3JvR2ucnixjR-1]

**Distribuição de tarefas:**

- [Todos os Integrantes]: [Realizamos levantamentamentos de tudo que foi feito nas aulas anteriores e as decisões técnicas]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Agrupar todos os dados utilizados e fazer o encaminhamento]

**Soluções adotadas:**

- Para [Agrupar todos os dados]: [Só necessitamos de tempo e paciência para conseguir juntar tudo]

**Conhecimentos adquiridos:**

- [Conhecimento das outras aulas]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Nenhum conceito foi necessário ser aplicado]

**Insights obtidos:**

- [Nenhum insight foi gerado]

**Conexões com conteúdos anteriores:**

- [Conexão com tudo que foi decidido e criado anteriormente]

### Próximos Passos

**Planejamento para próxima aula:**

- [Realizar o último diário de bordo]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Nenhum objetivo estipulado]

### Registros Visuais

[Tudo disponível pelo FIGMA]
