## Semana 9

### Informações Básicas

**Data:** DD/MM/AAAA
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Desenvolvimento de Protótipos de Média Fidelidade]

### Atividades Realizadas

**Descrição das atividades:**

- [Crie mockups mais detalhados com base nos wireframes; Utilize uma ferramenta digital, FIGMA foi o selecionado]
- [Hierarquia visual e tipografia e Esquema de cores básico]
- [Espacejamento e alinhamento e Elementos interativos (botões, menus, formulários]

**Artefatos produzidos:**

- [Wireframe via FIGMA] - [Link para acesso: https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?t=xDPc3JvR2ucnixjR-1]

**Distribuição de tarefas:**

- [Daniel, André e Lucas]: [Criação direta das telas e wireframes no figma]
- [Guilherme, Gustavo e Cauê]: [Verificar e pesquisar exmplos de telas normalmente usadas para estrutura onde o usuário insere, por meio de texto, audio ou video, o que necessita e o sistema responde em sequência]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Inspirações e decisões de quais layouts deveriamos estruturar]

**Soluções adotadas:**

- Para [Inspirações e decisões de quais layouts deveriamos estruturar]: [Optamos, pelo menos no inicio, utilizar uma estruturação básica, como o do google translate, e depois estar inserindo os recursos extras que possuimos]

**Conhecimentos adquiridos:**

- [Estrutura padrão de wireframes, vista principalmente em outra matéria, no caso UX Design]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Nenhum conceito teórico utilizado]

**Insights obtidos:**

- [Nenhum insight gerado]

**Conexões com conteúdos anteriores:**

- [Conexão com as aulas de UX Design e um pouco de semlhança com o Diagrama de Classes]

### Próximos Passos

**Planejamento para próxima aula:**

- [Prototipagem e Design de Interface: Aplicação de Princípios de Design Centrado no Usuário]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Finalizar o wireframe de média qualidade e iniciar a criação de alta qualidade das telas]

### Registros Visuais

[Telas disponibilizados no FIGMA]
