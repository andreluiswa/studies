## Semana 5

### Informações Básicas

**Data:** 01/04/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]

**Tema da semana:** [Verificação da qualidade de nossas histórias]

### Atividades Realizadas

**Descrição das atividades:**

- [Apresentamos ao professor e a alguns grupos o que foi criado por nosso grupo]

**Artefatos produzidos:**

- [Histórias de usuário] - [Localizado em docs/requisitos/histórias de usuário]

**Distribuição de tarefas:**

- [Todos os integrantes]: [Recebemos os feedbacks e realizamos anoações de nossos pontos principais e onde precisávamos melhorar]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Apresentar as histórias]

**Soluções adotadas:**

- Para [Apresentar as histórias]: [Reunimos todos do grupo e relatamos o que fizemos e oq eu prorizamos]

**Conhecimentos adquiridos:**

- [Tecnicamente, nenhum conhecimento, e sim feedbacks recebidos]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Nenhum conceito foi intencionalmente usado]

**Insights obtidos:**

- [Nenhum insight gerado]

**Conexões com conteúdos anteriores:**

- [Conexão com as pesquisas feitas nas semanas anteriores]

### Próximos Passos

**Planejamento para próxima aula:**

- [Início da criação do Diagrama de Classes]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Focar totalmente no Diagrama de Classes]

### Registros Visuais

[Nenhum registro visual gerado]
