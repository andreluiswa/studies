
## Semana 3

### Informações Básicas

**Data:** 18/03/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]

**Tema da semana:** [Refinar nossa Lista de Requisitos e iniciar o desenvolvimento das histórias]

### Atividades Realizadas

**Descrição das atividades:**

- [Deixamos Cauê e Gustavo responsáveis por dar mais detalhes a lista de requisitos]
- [Daniel e André foram responsáveis por pegar e verificar o que uma história de usuário precisa possuir]
- [Lucas e Guilherme foram responsáveis por comecçar a desenvolver as histórias com base nas informações obtidas pelo dois membros anteriores]

**Artefatos produzidos:**

- [Lista de Requisitos] - [Localizado tanto na semana 2 quanto e docs / requsitos / documento_requisitos]
- [História de usuário 1] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_1]
- [História de usuário 2] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_2]
**Distribuição de tarefas:**

- [Cauê e Gustavo]: [Refinar a lista de requisitos]
- [Daniel e André]: [Verificações e pesquisas sobre o que é, qual o objetivo e como criar uma históra de usuário]
- [Lucas e Guilherme]: [Criação das histórias em si]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Encontrar exemplos significativos de história de usuário]
- [Criação das histórias de usuário]

**Soluções adotadas:**

- Para [Encontrar exemplos significativos de história de usuário]: [Buscamos, via web, estruturas breves de histórias de usuário, além de tomar como base o exemplo aplicado pelo professor e sala]
- Para [Criação das histórias de usuário]: [Pesquisamos relatos de pessoas e usuários do tema do nosso trabalho, seja empecilhos encontrados durante o uso ou quais características achavam atraentes nesses apps usados por elas]

**Conhecimentos adquiridos:**

- [Estrutura básica de uma história de usuário]
- [Quais as necessiades de nossos usuários]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Scrum]: [Utilizamos sua facilidade em promover interações colaborativas e rápidas para desenvolver as histórias e verificar a opinião de cada membro do grupo]

**Insights obtidos:**

- [Nenhum insight gerado]

**Conexões com conteúdos anteriores:**

- [Verificamos que as histórias se conectam com os requisitos estipulados, por demonstram, na prática, como os requisitos estruturam o projeto inteiro]

### Próximos Passos

**Planejamento para próxima aula:**

- []

**Tarefas pendentes:**

- [Realizar, de casa, pesquisas e mais exemplos de histórias de usuário] - Responsável: [Todos os integrantes]

**Objetivos para próxima semana:**

- [Desenvolver ainda mais histórias]

### Registros Visuais

[Não houve registro visual]
