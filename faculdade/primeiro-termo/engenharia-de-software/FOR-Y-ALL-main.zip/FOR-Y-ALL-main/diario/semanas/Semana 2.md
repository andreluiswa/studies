## Semana 2

### Informações Básicas

**Data:** 11/03/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Fazer a elaboração do que será o nosso projeto e verificar quais requisitos/recursos são necessários]

### Atividades Realizadas

**Descrição das atividades:**

- [Pegamos exemplos de outros apps que também exercem funções de tradução, de diversos seguimentos diferentes, desde o Google Translate, que é um app mais objetivo, quanto do Duolingo, que é um app voltado a ensinar e não somente traduzir]
- [Fizemos pesquisa de quais requisitos são usados por estes mesmos apps pesquisados]
- [Depois de analisar quais são os requisitos, separamos quais seriam essenciais para desenvolver o projeto inicial e quais poderiam ser adiados e inplementados mais à frente]
**Artefatos produzidos:**

- [Foi gerado a nossa lista de requisitos do nosso projeto]
- [REQUISITOS - ENGENHARIA DE SOFTWARE]
- [Suporte a múltiplos idiomas: O aplicativo deve ser capaz de traduzir entre diversos idiomas, incluindo idiomas populares e menos comuns.
Interface intuitiva: A interface do usuário (UI) deve ser simples e fácil de navegar para todos os níveis de usuário.
Precisão na tradução: O aplicativo deve fornecer traduções precisas e contextualmente relevantes, com mínimo de erros.
Tradução de texto e voz: Deve permitir tanto a tradução de texto escrito quanto a tradução por meio de entrada de voz.
Reconhecimento de voz: O aplicativo deve ser capaz de reconhecer diferentes sotaques e pronúncias nas traduções por voz.
Armazenamento de histórico de traduções: O usuário deve poder acessar e revisar traduções anteriores.
Modo offline: Deve permitir a tradução sem necessidade de conexão com a internet, utilizando um banco de dados local.
Suporte a traduções de documentos: O aplicativo deve ser capaz de traduzir textos em diferentes formatos de documentos (PDF, DOCX, etc.).
Sincronização em múltiplos dispositivos: O usuário deve poder sincronizar seu histórico de traduções e preferências entre dispositivos diferentes.
Tradução contextual: O aplicativo deve entender o contexto das palavras e frases para oferecer traduções mais precisas (por exemplo, palavras com múltiplos significados).
Correção de gramática e estilo: O aplicativo pode sugerir melhorias no texto traduzido, oferecendo correções gramaticais e sugestões de estilo.
Suporte a tradução de imagens: A funcionalidade de OCR (Reconhecimento Óptico de Caracteres) deve permitir a tradução de texto dentro de imagens ou fotos.
Feedback do usuário: Os usuários devem poder fornecer feedback sobre a qualidade das traduções, ajudando a melhorar o sistema.
Segurança de dados: O aplicativo deve garantir que as traduções e dados do usuário sejam tratados de forma segura, com criptografia adequada.
Acessibilidade: O aplicativo deve ser acessível para usuários com necessidades especiais, como compatibilidade com leitores de tela ou tradução em linguagem de sinais.]

- [REQUISITOS NÃO FUNCIONAIS]
[1. Desempenho: O aplicativo deve fornecer traduções rápidas, com tempo de resposta inferior a 2 segundos para textos curtos.
2. Usabilidade: A interface do aplicativo deve ser intuitiva e fácil de usar, permitindo que qualquer usuário compreenda rapidamente como realizar uma tradução.
3. Segurança: O aplicativo deve garantir a proteção dos dados do usuário, criptografando informações sensíveis e respeitando a privacidade.
4. Compatibilidade: O aplicativo deve ser compatível com as versões mais recentes de iOS e Android, além de adaptar-se a diferentes tamanhos de tela de smartphones e tablets.
5. Disponibilidade: O aplicativo deve ter alta disponibilidade, com um tempo de inatividade inferior a 0,1% por mês.
6. Escalabilidade: O sistema deve ser capaz de suportar um aumento no número de usuários e traduções simultâneas sem comprometer o desempenho.
7. Manutenibilidade: O aplicativo deve ser de fácil manutenção, com uma arquitetura modular que permita a correção de bugs e implementação de novos recursos sem impactos significativos.
8. Acessibilidade: O aplicativo deve ser acessível para pessoas com deficiência, oferecendo suporte a leitor de tela e opções de alto contraste no design da interface.]

**Distribuição de tarefas:**

- [Daniel e André: Responsáveis por realizar a busca dos requisitos]
- [Lucas e Guilherme: Verificar quais itens eram necessários de primeiro momento]
- [Gustavo e Cauê:  Responsáveis por verificar o que poderia ser implemnetado depois e por criarem a lista final dos requisitos]
### Dificuldades e Soluções

**Desafios encontrados:**

- [Fazer uma pré seleção e pesquisar para ver o que poderia ser deixado de lado e o que seria crucial estar inserindo dentro da estrutura, onde tivemos que pedir auxílio tanto pela internet quanto para outras pessoas além do grupo para verificar o que sria necessário manter]

- [Saber quais apps deveríamos pegar como exemplo para estar baseando o nosso projeto, mas isso foi decidido por votação pelos integrantes do grupo]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Pesquisas virtuais e reuniões breves para estar fazendo tomadas de decisão]

**Insights obtidos:**

- [Nenhum insight foi gerado]

**Conexões com conteúdos anteriores:**

- [Não teve nenhuma conexão com o conteúdo anterior]

### Próximos Passos

**Planejamento para próxima aula:**

- [Refinar mais a nossa lista e fazer um breve desenvolvimento de nossa apresentação, além de iniciar o densenvolvimento de nossas histórias de usuário]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Possuir uma lista de requisitos apresentável e duas histórias de usuário para trabalhar em cima]

### Registros Visuais

[Não houve registros visuais]
