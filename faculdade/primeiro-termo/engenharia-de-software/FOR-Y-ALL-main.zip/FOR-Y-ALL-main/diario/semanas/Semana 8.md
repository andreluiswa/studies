## Semana 8

### Informações Básicas

**Data:** 29/04/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [PI: Design de Software]

### Atividades Realizadas

**Descrição das atividades:**

- [Selecionar um estilo arquitetural apropriado para o projeto]
- [Definir os principais componentes e suas responsabilidades]
- [Estabelecer como os componentes se comunicarão]

**Artefatos produzidos:**

- [documento_arquitetura.md] - [Localizado em docs/arquitetura/documento_arquitetura.md]

**Distribuição de tarefas:**

- [Daniel e André]: [Verificar os requisitos e objetivo do porjeto e identificarem qual o melhor modelo de arquitetura a se encaixar]
- [Lucas e Guilherme]: [Verificar novamente o Diagrama de Classes, confirmando se cada uma delas estavam com atributos e métodos definidos]
- [Gustavo e Cauê]: [Verificar, usando o SOLID, se estava tudo nos padrões necessários]
- [Todos os Integrantes]: [Criar um documento que contenha tudo isso para encaminhar na atividade semanal]
### Dificuldades e Soluções

**Desafios encontrados:**

- [Decidir qual Arquitetura iria se encaixar melhor, pois nenhuma sanou 100% os nossos itens]
- [Usar o SOLID e conseguir aplicá-lo de maneira efetiva]

**Soluções adotadas:**

- Para [Decidir qual Arquitetura iria se encaixar melhor]: [Optamos por usar aquela que mais resolve situações e se estrutura de acordo com os requisitos]
- Para [Usar o SOLID e conseguir aplicá-lo de maneira efetiva]: [Seguimos os passos disponibilizados pelo material do professor, de maneira lenta, mas que proporcionasse uma segurança de que fizemos certo a estrutura]

**Conhecimentos adquiridos:**

- [Uma melhor compreensão de para que serve o SOLID e como usá-lo para avaliar estruturas e funções, mantendo a essência de que cada item tenha uma única tarefa]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [SOLID]: [Usamos os 5 principios dele para avaliar cada aspecto de tudo que foi criado até então, fazendo a alteração de imediato quando algo não estava nos trâmites]

**Insights obtidos:**

- [Nenhum insight obtido]

**Conexões com conteúdos anteriores:**

- [Conexão com todos os itens das últimas semanas, já que basicamente fizemos as últimas modificações para inserir o modelo de arquitetura]

### Próximos Passos

**Planejamento para próxima aula:**

- [Iniciar o agrupamento dos documentos gerados e seguir o padrão desejado pelo professor]
**Tarefas pendentes:**

- [Tarefa da criação de novas histórias de usuário] - Responsável: [Daniel]

**Objetivos para próxima semana:**

- [Conseguir elaborar mais algumas histórias de usuário, assim para poder conseguir expandir mais o Diagrama de Classes]

### Registros Visuais

[Não houve registro visual]
