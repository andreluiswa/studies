## Semana 6

### Informações Básicas

**Data:** 15/04/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]

**Tema da semana:** [Diagrama de Classes INICIAL]

### Atividades Realizadas

**Descrição das atividades:**

- [Fomos apresentados à plataforma MERMAID]
- [Iniciamos a etapa de construção de Classes]
- [Com as histórias de usuário e com a lista de requisitos identificamos nossos prováveis clientes]
- [Iniciamos a estruturação de quem ou o quê será as nossas classes]
**Artefatos produzidos:**

- [Diagrama Inicial de Classes] - [Disponibilizado via link da própria plataforma do Mermaid ou em docs/arquitetura/documento_arquitetura.md]

**Distribuição de tarefas:**

- [Daniel e André]: [Criação do diagrama no próprio Mermaid]
- [Lucas e Guilherme]: [Verificar quais os comandos usar dentro do arquivo de guia que o Mermaid possui e passar para os membros anteriores]
- [Gustavo e Cauê]: [Verificavam o material de estudo do professor e via internet sobre como poderíamos deixar tudo mais fácil e visual]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Como desenvolver um diagrama onde as classes se conectavam e quais ações e características de cada uma delas]

**Soluções adotadas:**

- Para [Desenvolver um diagrama onde as classes]: [O próprio Mermaid tem um suporte sobre como criar e quais comandos usar]
- Para [Desenvolver um diagrama onde as classes]: [Realizamos diversas análises e pedimos auxílio para o professor para dar um exemplo sobre o que cada classe deveria ser elaborada, como visto no próprio Diagrama disponível]

**Conhecimentos adquiridos:**

- [Capacidade de analisar grupos e conseguir definir quais são suas prioridades dentro de um determinado projeto]
- [Conhecimento técnico sobre desenvolvimento de diagrama básico através da plataforma do Mermaid]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [SCRUM]: [Sua estrutura de fácil maleabilidade e de compreensão para que mantivéssemos o foco total naquilo que era o objetivo]
- [CODIFICAÇÃO]: [A códificação foi no código da estrutura do Diagrama de Classes]

**Insights obtidos:**

- [Insights ligados à outras duas matérias que possuímos, Pensamento Computacional e UX Design, onde a questão de priorização e de estrutura foram essenciais para manter tudo organizado]

**Conexões com conteúdos anteriores:**

- [Conexão direta com as histórias de usuário para definir o que seriam as nossas classes]

### Próximos Passos

**Planejamento para próxima aula:**

- [Detalhar e adicionar mais itens em nosso diagrama]
- [Fazer uma melhoria novamente nas histórias de usuário, pois com o Diagrama, percebemos que ainda faltava informações a ser obtidas com elas]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Fazer o Diagama ter mais informações de características da classe]
- [Tornar nossas histórias mais detalhadas, com informações quantitativas e não abrangentes]

### Registros Visuais

[Tudo feito no Mermaid]
