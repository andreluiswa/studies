## Semana 13

### Informações Básicas

**Data:** 26/05/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Refinamento dos Protótipos]

### Atividades Realizadas

**Descrição das atividades:**

- [Seguindo os resultados dos testes registrados no último registro, seguimos a priorização em ordem do que julgamos ser mais importante para entregar um bom resultado aos usuários na segunda fase de testes]

**Artefatos produzidos:**

- [Wireframe pelo FIGMA] - [Link de acesso: https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?t=xDPc3JvR2ucnixjR-1]
**Distribuição de tarefas:**

- [Daniel, André e lucas]: [Começamos pela Obstrução de informações da tela, que ao mesmo tempo era o principal empecilho era também o problema mais rápido de estar organizando, pois era a base das telas e das organizações das informações.Em seguida passamos pela falta de informações e de apresentação dos recursos, já que para estar apresentando os recursos, as informações precisam estar prontas para serem utilizadas. Recursos como captação de áudio, fotos, ou parte de suporte]
- [Guilherme, Gustavo e Cauê]: [Por fim, só organizamos os conteúdos e recursos disponíveis para estarem sendo dispostos de uma maneira confortável e de fácil acesso, onde os principais itens, os que serão mais utilizados, ficaram no campo de visão fácil do usuário, e os recursos de personalização ou de sub utilização, ficaram em outras telas]

### Dificuldades e Soluções

**Desafios encontrados:**

- [No caso terminamos de resolver o desafio do último diário]

**Soluções adotadas:**

**Conhecimentos adquiridos:**

- [Capacidades de estar realizando alterações sem precisar mudar o projeto inteiro, pois conseguimos manter eles organizados de maneira que era possível estar fazendo alterações individuais]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Scrum]: [Ambos auxiliaram na estruturação dos itens, onde cada um mantinha uma conexão com o outro e que fosse possível realizar modificações sem danificar o ambiente onde ele estava inserido]
- [Heuristicas de Nielsen]: [Ambos auxiliaram na estruturação dos itens, onde cada um mantinha uma conexão com o outro e que fosse possível realizar modificações sem danificar o ambiente onde ele estava inserido]

**Insights obtidos:**

- [Nenhum Insight gerado]

**Conexões com conteúdos anteriores:**

- [Conexão com a estrutura feita anteriormente, tomando como base as Heurísticas de Nielsen]

### Próximos Passos

**Planejamento para próxima aula:**

- [Se possível, fazer um teste de usabilidade de maneira rápida para adquirir mais feedbacks]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Prototipagem e Design de Interface: Elaboração de Guia de Estilo Básico]

### Registros Visuais

[Disponíveis através do FIGMA]
