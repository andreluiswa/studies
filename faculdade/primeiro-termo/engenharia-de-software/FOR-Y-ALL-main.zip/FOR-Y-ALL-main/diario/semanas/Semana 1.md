## Semana 1

### Informações Básicas

**Data:** 25/02/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Realizamos a estruturação de quem se tornaria parte da equipe]

### Atividades Realizadas

**Descrição das atividades:**

- [Realizamos uma busca de quais membros iriam se reunir ao grupo]
- [Definimos quem ficaria a cargo de cada função]
- [Fizemos uma breve reuinão para verificar se todos estavam de acordo com as decisões tomadas]

**Artefatos produzidos:**

- [Não teve um artefato gerado]

**Distribuição de tarefas:**

- [A tarefa foi a estruturação da própria equipe]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Identificar quem seriam as pessoas que agregariam ao nosso projeto e em nosso conhecimento como equipe]

- [Realizamos uma busca entre os alunos, questionando quem estaria sem um grupo, e se estariam interessados em se juntar ao nosso]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Pode-se dizer que foi utilizadoo entrevistas, onde cada pessoa realizou a apresentação de si mesmo e respondeu a perguntas feitas pelos outros participantes]

**Insights obtidos:**

- [Nenhum insight foi gerado]

**Conexões com conteúdos anteriores:**

- [Não tivemos relação]

### Próximos Passos

**Planejamento para próxima aula:**

- [Definição mas concreto do que nosso projeto visaria e quais os recursos iniciais para isso]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Ter uma meta em mente e um objetivo do que queremos apresentar e desenvolver]

### Registros Visuais

[Não houve registros visuais]
