## Semana X

### Informações Básicas

**Data:** 22/04/2025 à 29/04/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Reavaliação das histórias de usuários]

### Atividades Realizadas

**Descrição das atividades:**

- [Durante a semana disponibilizada trabalhamos em cima das 6 histórias que tínhamos]
- [Focamos em dar o máximo de detalhes para elas, e, se possível, criar alguma história nova]
- [O objetivo era deixar concreto, fugindo do abstrato e do genérico]

**Artefatos produzidos:**

- [Histórias de usuário] - [Localizado em docs/requisitos/histórias de usuário]

**Distribuição de tarefas:**

- [Daniel e André]: [Responsáveis pelas histórias 3 e 4]
- [Lucas e Guilherme]: [Responsáveis pelas histórias 1 e 2]
- [Gustavo e Cauê]: [Responsáveis pelas histórias 5 e 6]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Conseguir modificar as histórias de uma maneira que fiquem objetivas]

**Soluções adotadas:**

- Para [Conseguir modificar as histórias de uma maneira que fiquem objetivas]: [Buscamos colocar números e limites sobre o que era solicitado para tornar mais vísivel e fácil de mensurar]

**Conhecimentos adquiridos:**

- [Capacidade de distribuir e fazer medições sobre o que será solicitado pelos futuros usuários]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Historias de Usuário]: [Desenvolvimento total de histórias para podermos criar algo tangível com o projeto, e não somente ficar teorizando]

**Insights obtidos:**

- [Nenhum Insight gerado]

**Conexões com conteúdos anteriores:**

- [Total conexão com as próprias histórias de usuário projetadas no inicio e também com o Diagrama de Classes, já que o diagrama precisava de informações que não se encontrava dentro das historias, logo, elas precisavam ser alteradas]

### Próximos Passos

**Planejamento para próxima aula:**

- [Fazer um levantamento de tudo que desenvolvemos e fazer uma discussão sobre o que devemos melhorar e quais os processos seguintes a ser iniciados]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Conseguir criar um documento que tenha, mesmo que em resumo, o que temos, o que precisamos melhorar e o que precisa ser feito]

### Registros Visuais

[Nenhum registro visual gerado]
