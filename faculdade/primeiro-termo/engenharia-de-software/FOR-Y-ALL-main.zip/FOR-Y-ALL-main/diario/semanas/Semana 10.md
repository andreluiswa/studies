## Semana 10

### Informações Básicas

**Data:** 22/04/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Aplicação de Princípios de Design Centrado no Usuário]

### Atividades Realizadas

**Descrição das atividades:**

- [Revise os protótipos considerando as personas criadas anteriormente; Analise cada fluxo do ponto de vista do usuário]
- [Aplique as heurísticas de Nielsen para identificar problemas potenciais; Documente observações e melhorias propostas]

**Artefatos produzidos:**

- [Wireframe no FIGMA] - [Link do FIGMA: https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?t=xDPc3JvR2ucnixjR-1]

**Distribuição de tarefas:**

- [Daniel e André]: [Ambos propuseram sincronia entre as telas dentro da interface do aplicativo, já que causa boa sensação visual e de conforto, deixando tudo mais padronizado e sinérgico. Além de realizarem a pesquisa para verificar quais cores melhor seriam implementadas para o objetivo do projeto]
- [Gustavo e Cauê]: [Sugeriram ícones padrões que são conhecidos por boa parte do público e que servem para fornecer ferramentas de uso comum, como áudio, imagem ou texto]
- [Lucas e Guilherme]: [Comentaram sobre a aplicação de ferramentas de auxílio para que os usuários não se sintam perdidos na hora da utilização do app (ferramentas como: personalização de perfil, botões de pesquisa, entre outros)]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Se colocar como usuário final do app e não como um densenvolvedor]
- [Avaliar se todas as 10 heurísticas estavam sendo respeitadas e bem organizadas, sem causar uma sobrecarga de informações na tela do usuário] 

**Soluções adotadas:**

- Para [Se colocar como usuário final do app e não como um densenvolvedor]: [Evitamos pensamentos técnicos ao máximo e decidimos realizar o teste com outras pessoas mais à frente]
- Para [Avaliar se todas as 10 heurísticas estavam sendo respeitadas e bem organizadas]: [Efetuamos buscas de quais principais ferramentas eram disponibilizados aos usuários, como vídeo e áudio]

**Conhecimentos adquiridos:**

- [Ferramentas, atalhos e serviços que agregam de maneira essencial para as pessoas por evitar pensar pesadamente e que são intuitivas]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Heuristicas de Nielsen]: [Cada item exercido pelos integrantes foram analisadas pelos outros 4 pasra verificar se seguia o padrão]

**Insights obtidos:**

- [Nenhum Insight gerado]

**Conexões com conteúdos anteriores:**

- [Conexão com as teals pesquisadas no diário anterior]

### Próximos Passos

**Planejamento para próxima aula:**

- [Prototipagem e Design de Interface: Considerações de Acessibilidade]
**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Conseguir com que esses recursos analisados sejam abrangentes para diferentes públicos]

### Registros Visuais

[Os registros estão disponíveis pelo link do FIGMA]
