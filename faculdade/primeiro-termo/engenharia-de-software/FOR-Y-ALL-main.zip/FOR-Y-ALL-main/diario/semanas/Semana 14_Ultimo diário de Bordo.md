## Semana 14

### Informações Básicas

**Data:** 27/05/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Atualização do Diário de Bordo]

### Atividades Realizadas

**Descrição das atividades:**

- [\#\# Registro de Sessões

\#\#\# Sessão \#\[Número\] \- \[20/05/2025\] \- \[27/05/2025\]

\#\#\#\# Cabeçalho

\- \[20/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Desenvolvimento do protótipo de Média Fidelidade  
   
\- \[21/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Aplicação de Princípios de Design Centrado no Usuário

\- \[22/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Considerações de Acessibilidade

\- \[23/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Condução de Testes de Usabilidade Simplificados

\- \[24/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Ligação:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Refinamento dos Protótipos

\- \[27/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

- [\- \*\*Objetivos da Sessão:\*\*  
\#Elaboração de Guia de Estilo Básico

\- \[27/05/2025\] \- \[19:20\] às \[22:30\]  
\- \*\*Unimar:\*\* \[Presencial/Remoto\]  
\- \*\*Participantes Presentes:\*\*  
\[André Luis\] – DEV  
\[Guilherme Teixeira\] – Scrum Master  
\[Gustavo de Oliveira\] – Product Owner  
\[Caue Moreno\] – DEV  
\[Lucas Vitor\] – DEV  
\[Daniel dos Santos\] – DEV]

**Artefatos produzidos:**

- [Os dia´rios anteriores à este]

**Distribuição de tarefas:**

- [Todos os Integrantes]: [Atualizar o último diário de bordo]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Nenhum desafio na consytrução deste diário]

**Soluções adotadas:**

- [Não teve Desafio]

**Conhecimentos adquiridos:**

- [Conhecimento relatado nos outros diários sobre temas do semestre inteiro]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Nenhum conceito necessário neste último diário]

**Insights obtidos:**

- [Nenhum Insight gerado]

**Conexões com conteúdos anteriores:**

- [Todos os Conteúdos desenvolvidos até então]

### Próximos Passos

**Planejamento para próxima aula:**

- [Sem planejamento]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Sem objetivos elaborados]
### Registros Visuais

[Tudo disponibilizado anteriormente nos diários anteriores]
