## Semana 12

### Informações Básicas

**Data:** 24/05/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Condução de Testes de Usabilidade Simplificados]

### Atividades Realizadas

**Descrição das atividades:**

- [Roteiro do teste:Colocamos os participantes para estarem fazendo as primeiras interações com as telas do wireframe, onde deixamos eles sem o acesso nas últimas estruturações do mesmo, onde cada a cada um seria apresentado o mvp do wireframe pelos guias e eles colocariam suas opiniões, sugestões de melhoria e incômodos no uso]

**Artefatos produzidos:**

- [Nenhum artefato gerado]

**Distribuição de tarefas:**

- [Daniel]: [Guia]
- [Gustavo]: [Observador]
- [Lucas]: [Guia]
- [André]: [Observador]
- [Guilherme]: [Participante]
- [Cauê]: [Participante]


### Dificuldades e Soluções

**Desafios encontrados:**

- [Obstrução de informações nas telas principais]
- [Campos com tamanhos muitos diversificados e que não se ornam]
- [Falta de apresentação dos recursos disponíveis]

**Soluções adotadas:**

- Para [Todos os desafios]: [Reorganização dos campos de inserimento de dados e dos textos de respostas; Melhoria da sincronia das cores e dos tons utilizados; Breves textos guias e informações autoexplicativas; Breve separação das diferentes telas de uso]

**Conhecimentos adquiridos:**

- [Compreensão de que sempre devemos estar testando e aprimorando o que foi feito, pois mesma com toda a nossa preparação, problemas foram encontrados]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Teste de Usabilidade]: [Serviu como uma experiência do que aconteceria na prática, quando os reais usuários fizessem a utilização do projeto]

**Insights obtidos:**

- [Nenhum insight obtido]

**Conexões com conteúdos anteriores:**

- [Conexão com as estruturas e decisões visuais colocadas na atividade anterior]

### Próximos Passos

**Planejamento para próxima aula:**

- [Prototipagem e Design de Interface: Refinamento dos Protótipos]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Iniciar o protótipo de wireframe de alta qualidade e fazer todas as correções devidas]

### Registros Visuais

[Recursos visuais disponíveis pelo FIGMA]
