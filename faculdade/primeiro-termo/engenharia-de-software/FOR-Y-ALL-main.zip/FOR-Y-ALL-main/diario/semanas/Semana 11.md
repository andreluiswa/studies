## Semana 11

### Informações Básicas

**Data:** 23/05/20
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Prototipagem e Design de Interface: Considerações de Acessibilidade]

### Atividades Realizadas

**Descrição das atividades:**

- [Avalie os protótipos quanto à acessibilidade básica e verifique aspectos como: Contraste de cores; Tamanho de texto e legibilidade; Alternativas para conteúdo não-textual; Navegabilidade via teclado]

**Artefatos produzidos:**

- [Wireframe no FIGMA] - [Link de acesso: https://www.figma.com/design/n1k1pSeEFGtN7PwABFD4TP/For-Y-All_Projeto_EnegnhariaDeSoftware_MQ?t=xDPc3JvR2ucnixjR-1]

**Distribuição de tarefas:**

- [Daniel, André e Lucas]: [Contraste de Cores e Tamanho de Texto e Legibilidade]
- [Guilherme, Gustavo e Cauê]: [Alternativas para Conteúdo Não-Textual e Navegabilidade via Teclado]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Não houve um desafio de fato, realizamos pesquisas para verificar nossos embasamentos e decisões tomadas]
**Soluções adotadas:**

**Conhecimentos adquiridos:**

- [Conhecimento de combinação das cores e quais tamnhos de fontes são orientados para cada objetivo]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Teoria das Cores]: [Na escolha de quais seriam as cores bases de nosso wireframe]
**Insights obtidos:**

- [nenhum insight obtido]

**Conexões com conteúdos anteriores:**

- [Conexão com os recursos de atalho do diário anterior]

### Próximos Passos

**Planejamento para próxima aula:**

- [Prototipagem e Design de Interface: Condução de Testes de Usabilidade Simplificados]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Conseguir realizar um roteiro de teste para a utilização do wireframe]
### Registros Visuais

[Registros disponíveis no FIGMA]
