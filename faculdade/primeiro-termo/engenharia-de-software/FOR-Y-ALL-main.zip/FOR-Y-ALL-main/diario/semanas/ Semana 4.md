## Semana 4

### Informações Básicas

**Data:** 25/03/2025
**Membros presentes:** [Gustavo de Oliveira] - [Project Owner/PO]
[Guilherme Alves] - [Scrum Master]
[Daniel dos Santos] - [DEV]
[André luis] - [DEV]
[Lucas Vitor] - [DEV]
[Caue Moreno] - [DEV]
**Tema da semana:** [Aprimoramento das histórias de usuário]

### Atividades Realizadas

**Descrição das atividades:**

- [Criamos mais histórias de usuário em casa e trouxemos para a aula]
- [Refinamos nossas histórias depois da apresentação das mesmas que foram feitas]

**Artefatos produzidos:**

- [História 3] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_3]
- [História 4] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_4]
- [História 5] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_5]
- [História 6] - [Localizado em docs/requisitos/histórias de usuário/história_de_usuário_6]
**Distribuição de tarefas:**

- [Todos os integrantes]: [Desenvolvimento de novas histórias que poderiam ser utilizadas em nosso projeto]

### Dificuldades e Soluções

**Desafios encontrados:**

- [Ter criatividade para estar desenvolvendo histórias, mesmo já tendo visto exemplos de como elas devem ser elaboradas]

**Soluções adotadas:**

- Para [Ter criatividade para estar desenvolvendo histórias]: [Perguntamos diretamente ao professor sobre como criar histórias objetivas e simples sem cair ao genérico]

**Conhecimentos adquiridos:**

- [Capacidade de imaginar e construir possíveis cenários do que poderá ocorrer durante o uso de nosso projeto]

### Reflexão sobre Aplicação dos Conceitos

**Conceitos teóricos aplicados:**

- [Modelo Cascata]: [Planejamos o que nossas histórias deveriam possuir no final, pensamos em maneiras para executar e implementar tais características e por fim realizamos a criação das mesmas]

**Insights obtidos:**

- [Nenhum insight gerado]

**Conexões com conteúdos anteriores:**

- [Verificamos que as histórias se conectam com os requisitos estipulados, por demonstram, na prática, como os requisitos estruturam o projeto inteiro]

### Próximos Passos

**Planejamento para próxima aula:**

- [Apresentar as histórias e receber um feedback de como elas estão em quesito de qualidade]

**Tarefas pendentes:**

- [Nenhuma tarefa pendente]

**Objetivos para próxima semana:**

- [Ter uma lista de histórias fixas e, se possível, criar mais algumas]

### Registros Visuais

[Não houve nenhum registro visual]
