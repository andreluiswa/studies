# Documento de Arquitetura

## Histórico de Revisões desde Arquivo

| Data       | Versão | Descrição                | Autor  |
| ---------- | ------ | ------------------------ | ------ |
| 15/04/2025 | 1.0    | Versão inicial           | [Daniel, Guilherme] |
| 22/04/2025 | 1.1    | [Definimos com mais detalhes e clareza as classes e seguimos seu modelo de arquitetura.] | [Daniel, André, Guilherme, Lucas, Gustavo] |

## 1. Introdução

### 1.1 Finalidade

[Este documento tem como finalidade descrever a arquitetura do sistema de tradução desenvolvido, abordando sua estrutura de componentes, tecnologias utilizadas e os padrões arquiteturais adotados.]

### 1.2 Escopo

[O sistema descrito é um aplicativo de tradução de idiomas que utiliza funcionalidades como OCR, reconhecimento de contexto, preferências de usuário e tradução offline. O escopo abrange a arquitetura de software necessária para suportar tanto a camada cliente (interface do usuário) quanto a camada servidor (processamento e respostas), com foco em modularidade, escalabilidade e experiência do usuário.]

### 1.3 Definições, Acrônimos e Abreviações

[OCR: Optical Character Recognition (Reconhecimento Óptico de Caracteres),
API: Application Programming Interface,
UI: User Interface (Interface do Usuário),
UX: User Experience (Experiência do Usuário),
REST: Representational State Transfer,
JSON: JavaScript Object Notation,
DB: Database,
CDN: Content Delivery Network,]

## 2. Representação Arquitetural

### 2.1 Modelo Arquitetural

[ARQUITETURA CLIENTE - SERVIDOR]

### 2.2 Justificativa

[Como nosso projeto tem a função de ser um aplicativo de tradução, o modelo que melhor se encaixou foi Cliente - Servidor, já que o aplicativo realiza requisições do usuário (textos a serem traduzidos) e responde com os dados processados de forma dinâmica. Esse modelo favorece atualizações frequentes do servidor, facilita o suporte a múltiplos idiomas e permite escalabilidade sem impactar diretamente o cliente.

## 3. Metas e Restrições da Arquitetura

### 3.1 Metas

[Garantir uma experiência de usuário fluida e responsiva;
Suportar traduções offline e online;
Prover personalização por parte do usuário (ex: sotaque, formalidade);
Escalabilidade para múltiplos idiomas e regiões;
Modularidade no código para facilitar a manutenção.]

### 3.2 Restrições

- [Tempo de resposta inferior a 2 segundos por requisição.]
- [Suporte a no mínimo 10 idiomas diferentes.]
- [Funcionamento offline limitado às traduções previamente baixadas.]
- [Dependência de bibliotecas OCR de terceiros.]

## 4. Visão de Casos de Uso

### 4.1 Diagrama de Casos de Uso

[Não utilizamos isso.]

### 4.2 Descrição dos Casos de Uso Significativos

[Não utilizamos isso.]

## 5. Visão Lógica

### 5.1 Visão Geral

[A arquitetura lógica é composta por camadas claramente definidas: Apresentação (UI), Lógica de Negócio (Controladores e Serviços), e Persistência (acesso a banco local e remoto). A separação em módulos facilita manutenção e testes.]

### 5.2 Pacotes de Design Significativos

[`ui`: telas, botões e interação com o usuário;]

[`services`: serviços de tradução, OCR, preferências;]

[`data`: acesso a banco de dados local;]

[`network`: comunicação com servidor via API;]

[`models`: classes de dados como `Usuario`, `Localizacao`.]

### 5.3 Diagramas de Classes

[Link do Arquivo: https://www.mermaidchart.com/app/projects/71728d38-f81d-4a07-8dbb-04966751b279/diagrams/c07f4d01-e9cd-4f0d-b10b-10f440981267/version/v0.1/edit]

```mermaid

classDiagram
direction TB
    class Usuario {
	    +idade : int
	    +nivelDeConhecimento : int
    }

    class Localizacao {
	    +linguaNativa : str
	    +linguaDestinada : str
	    +traducao() : void
    }

    class Preferencias {
	    +formalidade : str
	    +sotaque : str
	    +contexto : str
    }

    class Comunicacao {
	    +OCR Translate() : void
    }

    class Tela {
	    +comandosSimples : str
	    +pontosFocais() : void
    }

    class Tecla {
	    +botoesIntuitivos() : void
    }

    class Conexao {
	    +pacotesDeIdiomas() : void
    }

    class Arquivos {
        +traduzesOffline() : void
    }
    Usuario --> Tela
    Tela --> Tecla
    Tecla --> Comunicacao
    Tecla --> Localizacao
    Tecla --> Conexao
    Tecla --> Arquivos
    Localizacao --> Preferencias

```

## 6. Visão de Processos

[Não utilizamos isso.]

## 7. Visão de Implantação

### 7.1 Diagrama de Implantação

[Não utilizamos isso.]

### 7.2 Descrição dos Nós

[Não utilizamos isso.]

## 8. Visão de Implementação

### 8.1 Visão Geral

[Não utilizamos isso.]

### 8.2 Camadas

[Não utilizamos isso.]

## 9. Visão de Dados

### 9.1 Modelo de Dados

[Não utilizamos isso.]

## 10. Tamanho e Performance

[Tempo máximo de resposta: 2 segundos, Tamanho máximo do app: 100MB, Tempo de inicialização: < 3 segundos, Cache de até 50 traduções recentes, Pacotes offline com até 20MB por idioma]

## 11. Qualidade

[Usabilidade: Interface intuitiva com comandos simples, Confiabilidade: Sistema responde de forma previsível a entradas válidas, Portabilidade: Compatível com múltiplos dispositivos, Desempenho: Baixa latência nas traduções online e rápido acesso offline, Segurança: Armazenamento local criptografado e comunicação via HTTPS]

## 12. Princípios SOLID Aplicados

- [S (Responsabilidade Única): Cada classe possui uma única responsabilidade (ex: Localizacao, Usuario, etc.)]
- [O (Aberto/Fechado): Módulos para idiomas ou preferências são extensíveis sem alterar o núcleo]
- [L (Substituição de Liskov): Substituição segura nas interfaces de serviços]
- [I (Segregação de Interface): Interfaces específicas para OCR, Tradução, Preferências]
- [D (Inversão de Dependência): Uso de injeção de dependência entre módulos e serviços]

## 13. Padrões de Design Utilizados

- [MVC: Separação entre UI, lógica e dados]
- [Factory Method: Para instanciar serviços de tradução conforme idioma]
- [Repository: Camada de abstração para acesso a dados locais/remotos]
- [Observer: Atualizações em tempo real na UI após mudanças de estado]
- [Strategy: Seleção dinâmica de estilo de tradução (ex: formal vs informal)]

>[!TIP]
>Ao longo do desenvolvimento, revise este documento para garantir que a implementação esteja alinhada com a arquitetura planejada. Documente as decisões arquiteturais importantes, incluindo as alternativas consideradas e os motivos da escolha final.
