# Caso de Teste: [4]

## Título

[Verificar reconhecimento de voz e tradução automática com suporte a sotaques]

## Objetivo

[Validar se o sistema reconhece e transcreve falas com pelo menos 90% de precisão, mesmo com variações de sotaque e ritmo, além de permitir ativação ou desativação da tradução automática após a fala.]

## Requisitos/Histórias Relacionados

- [Tradução de texto e voz: Deve permitir tanto a tradução de texto escrito quanto a tradução por meio de entrada de voz.]

## Pré-condições

1. [Reconhecer e transcrever voz com pelo menos 90% de precisão.]
2. [Suportar sotaques variados e diferentes ritmos de fala.]
3. [Permitir ativação/desativação de tradução automática após a fala.]

## Dados de Teste

- [Frase de entrada: “Gostaria de pedir uma pizza média de queijo e frango.”]
- [Idioma de origem: Português (com diferentes sotaques: paulista, nordestino, sulista)]
- [Idioma de destino: Espanhol]

## Passos

1. [Acessar o sistema com a função de entrada por voz ativa.]
2. [Pronunciar a frase de teste com sotaque padrão.]
3. [Verificar se a transcrição de voz corresponde à fala com pelo menos 90% de precisão.]
4. [Repetir a frase com variações de sotaque e ritmo.]
5. [Observar se a precisão da transcrição se mantém acima de 90%.]
6. [Ativar a tradução automática e verificar se a tradução da transcrição é exibida corretamente.]
7. [Desativar a tradução automática e confirmar que novas falas não são traduzidas automaticamente.]
8. [Reativar a tradução automática e testar novamente a funcionalidade]

## Resultado Esperado

[O sistema reconhece e transcreve corretamente a fala com precisão superior a 90%, independentemente do sotaque ou ritmo.

A tradução automática pode ser ativada ou desativada conforme o controle do usuário.

A tradução do texto reconhecido é fiel e coerente com a fala original.

A interface indica claramente o status da tradução automática (ativa ou inativa).]

## Pós-condições

1. [Transcrição da fala armazenada ou exibida corretamente.]
2. [Tradução executada ou interrompida conforme o controle do usuário.]
3. [Sistema permanece estável após alternância entre ativação e desativação da função.]

## Tipo de Teste

[Sistema / Aceitação]

## Automação

[Status de automação: Manual]

## Prioridade

[Alta]

## Observações

[Recomenda-se a execução deste teste com ao menos três pessoas diferentes, com sotaques distintos, para validar a robustez do reconhecimento de voz.]
