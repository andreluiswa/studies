# Caso de Teste: [ID]

## Título

[Título conciso do caso de teste]

## Objetivo

[Objetivo do teste]

## Requisitos/Histórias Relacionados

- [Requisito/História 1]
- [Requisito/História 2]
- [Requisito/História n]

## Pré-condições

1. [Pré-condição 1]
2. [Pré-condição 2]
3. [Pré-condição n]

## Dados de Teste

- [Dados necessários para execução do teste]

## Passos

1. [Passo 1]
2. [Passo 2]
3. [Passo n]

## Resultado Esperado

[Descrição do resultado esperado]

## Pós-condições

1. [Pós-condição 1]
2. [Pós-condição 2]
3. [Pós-condição n]

## Tipo de Teste

[Unitário, Integração, Sistema, Aceitação, etc.]

## Automação

[Status de automação: Manual, Automatizado, Em progresso]

## Prioridade

[Alta, Média, Baixa]

## Observações

[Observações adicionais, se houver]
