# Caso de Teste: [7]

## Título

[Verificar exibição e sincronização do histórico de traduções]

## Objetivo

[Garantir que o histórico de traduções seja exibido corretamente com data/hora e tipo de tradução, esteja sincronizado entre dispositivos após login e possa ser exportado como arquivo.]

## Requisitos/Histórias Relacionados

- [Backend com autenticação e sincronização via Firebase/Cloud, com salvamento seguro (criptografado).]

## Pré-condições

1. [Histórico deve ser exibido com data/hora e tipo de tradução (texto, voz, imagem).]
2. [Sincronização entre dispositivos deve ser automática após login.]
3. [Deve existir opção de exportar o histórico como arquivo.]

## Dados de Teste

- [Usuário com conta válida e histórico de traduções registrado previamente.]
- [Dispositivo A e Dispositivo B logados com a mesma conta.]
- [Tipos de tradução: Texto, Voz, Imagem.]
- [Histórico contendo registros de diferentes tipos de tradução em diferentes datas/horas.]

## Passos

1. [Realizar login com a conta de teste no Dispositivo A.]
2. [Navegar até a seção de "Histórico de Traduções".]
3. [Verificar se cada item do histórico exibe corretamente a data/hora e o tipo de tradução.]
4. [Realizar logout no Dispositivo A.]
5. [Realizar login no Dispositivo B com a mesma conta.]
6. [Verificar se o histórico de traduções está sincronizado e corresponde ao do Dispositivo A.]
7. [Acessar a opção de exportação do histórico.]
8. [Exportar o histórico como arquivo e verificar seu conteúdo.]

## Resultado Esperado

[O histórico é exibido corretamente com data/hora e tipo de tradução.

Após login em outro dispositivo, o histórico é sincronizado automaticamente e corresponde ao anteriormente visto.

O arquivo exportado contém todo o histórico corretamente formatado e legível.]

## Pós-condições

1. [Histórico permanece salvo e sincronizado na conta do usuário.]
2. [Arquivo exportado permanece disponível para download ou visualização.]
3. [Sessão permanece ativa no Dispositivo B.]

## Tipo de Teste

[Sistema]

## Automação

[Status de automação: Em progresso]

## Prioridade

[Alta]

## Observações

[Usuário poderá ativar ou desativar o armazenamento de histórico nas configurações. Confirmar compatibilidade da exportação com diferentes formatos (por exemplo, .txt, .csv, .pdf, conforme implementado).]
