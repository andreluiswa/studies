# Caso de Teste: [5]

## Título

[Verificar funcionamento do modo offline e acesso ao histórico de traduções]

## Objetivo

[Garantir que o sistema funcione corretamente no modo offline, oferecendo suporte a pelo menos 5 idiomas com um banco de dados local leve (menos de 200 MB), mantendo a precisão da tradução e armazenando o histórico para consulta posterior.]

## Requisitos/Histórias Relacionados

- [Armazenamento de histórico de traduções: O usuário deve poder acessar e revisar traduções anteriores]
- [Modo offline: Deve permitir a tradução sem necessidade de conexão com a internet, utilizando um banco de dados local.]

## Pré-condições

1. [Suporte a pelo menos 5 idiomas no modo offline.]
2. [Banco de dados local deve ser leve (< 200 MB).]
3. [Tradução offline deve ser tão precisa quanto possível.]

## Dados de Teste

- [Idiomas a serem testados offline: Português, Inglês, Espanhol, Francês, Alemão]
- [Frase de entrada: “Onde fica o ponto de ônibus mais próximo?”]
- [Tradução esperada (por exemplo, em inglês): “Where is the nearest bus stop?”]
- [Histórico prévio: ao menos 3 traduções anteriores salvas.]

## Passos

1. [Colocar o dispositivo em modo avião (sem conexão à internet).]
2. [Abrir o aplicativo e acessar o modo de tradução offline.]
3. [Selecionar um par de idiomas disponíveis offline (ex: Português ↔ Inglês).]
4. [Inserir a frase de teste e executar a tradução.]
5. [Verificar a qualidade e precisão da tradução gerada.]
6. [Repetir o teste com os outros 4 idiomas suportados.]
7. [Acessar a seção de histórico de traduções.]
8. [Confirmar que as traduções anteriores estão armazenadas corretamente e visíveis mesmo offline.]
9. [Validar que o tamanho do banco de dados local está dentro do limite especificado.]

## Resultado Esperado

[O sistema realiza traduções sem internet, com resultados coerentes e de boa qualidade.

Suporta pelo menos 5 idiomas diferentes no modo offline.

O banco de dados local é inferior a 200 MB.

O histórico de traduções pode ser acessado corretamente e inclui as traduções recentes e anteriores.

A interface permanece responsiva e funcional durante todo o teste.]

## Pós-condições

1. [Traduções executadas corretamente no modo offline.]
2. [Histórico de traduções armazenado e acessível.]
3. [Nenhum erro ou travamento durante a operação offline.]

## Tipo de Teste

[Sistema / Aceitação]

## Automação

[Status de automação: Manual]

## Prioridade

[Alta]

## Observações

[É recomendado verificar o tamanho real do banco de dados local após o teste em múltiplos idiomas, e repetir o procedimento em diferentes dispositivos para avaliar a consistência do modo offline.]
