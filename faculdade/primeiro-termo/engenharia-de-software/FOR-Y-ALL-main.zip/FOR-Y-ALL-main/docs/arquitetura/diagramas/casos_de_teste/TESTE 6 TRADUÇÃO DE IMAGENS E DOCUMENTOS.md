# Caso de Teste: [6]

## Título

[Verificar tradução de documentos com reconhecimento de texto (OCR) e seleção de trechos]

## Objetivo

[Validar a capacidade do sistema de reconhecer texto em documentos diversos (PDF, DOCX, JPG, PNG) com precisão mínima de 85% por OCR, permitir a seleção de trechos e realizar a tradução corretamente.]

## Requisitos/Histórias Relacionados

- [Suporte a traduções de documentos: O aplicativo deve ser capaz de traduzir textos em diferentes formatos de documentos (PDF, DOCX, etc.)]

## Pré-condições

1. [Reconhecer texto em imagens com OCR de pelo menos 85% de precisão.]
2. [Suportar documentos nos formatos PDF, DOCX, JPG e PNG.]
3. [Permitir seleção de trechos antes da tradução.]

## Dados de Teste

- [Documento de teste nos formatos:]
- [documento_teste.pdf]
- [documento_teste.docx]
- [imagem_teste.jpg]
- [imagem_teste.png]
- [Conteúdo: trecho curto com frases simples, exemplo: "O exame ocorrerá na próxima terça-feira, às 14h."]
- [Idioma de origem: Português]
- [Idioma de destino: Inglês]

## Passos

1. [Acessar a funcionalidade de tradução de documentos no sistema.]
2. [Fazer upload do documento no formato PDF.]
3. [Selecionar um trecho específico do conteúdo detectado.]
4. [Verificar a precisão do texto extraído por OCR (mínimo 85%).]
5. [Executar a tradução do trecho selecionado.]
6. [Repetir os passos de 2 a 5 para os formatos DOCX, JPG e PNG.]
7. [Comparar os resultados de reconhecimento e tradução entre os formatos.]
8. [Confirmar que o sistema permite ao usuário escolher o trecho desejado antes de traduzir.]

## Resultado Esperado

[O texto dos documentos é reconhecido com no mínimo 85% de precisão (OCR).

O sistema permite selecionar trechos do documento antes da tradução.

A tradução dos trechos selecionados é executada com coerência e sem erros críticos.

Todos os formatos especificados são aceitos e processados corretamente.]

## Pós-condições

1. [Traduções geradas a partir dos documentos ficam disponíveis para visualização]
2. [O trecho traduzido pode ser exportado ou copiado, conforme funcionalidade da interface.]
3. [Nenhum erro de carregamento, reconhecimento ou tradução ao longo do processo.]

## Tipo de Teste

[Sistema / Aceitação]

## Automação

[Status de automação: Manual]

## Prioridade

[Alta]

## Observações

[A precisão do OCR pode variar conforme a qualidade da imagem/documento. Recomenda-se testar também documentos com diferentes resoluções e fontes.]
